# -*- coding: utf-8 -*-
from odoo import fields, models


class TxLogisticaStage(models.Model):
    _name = "tx.logistica.stage"
    _description = "Transaccion Logistica Stages"
    _rec_name = 'name'
    _order = "sequence, name, id"

    name = fields.Char('Stage Name', required=True, translate=True)
    sequence = fields.Integer('Sequence', default=1, help="Used to order stages. Lower is better.")
    fold = fields.Boolean('Folded in Kanban', help='This stage is folded in the kanban view when there are no records in that stage to display.')
    company_id = fields.Many2one('res.company', string='Company', index=True, store=True)
    done = fields.Boolean('Done Stage', help='This is a DONE stage?.')

    # Este campo lo usamos como source para el stage_color
    color = fields.Selection([
        ('info', 'Azul'),
        ('success', 'Verde'),
        ('primary', 'Violeta'),
        ('warning', 'Café'),
        ('muted', 'Gris'),
        ('danger', 'Rojo')],
        string='Color', default="muted")
