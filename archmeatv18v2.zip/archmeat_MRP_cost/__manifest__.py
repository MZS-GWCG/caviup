{
    'name': 'ArchMeat MRP Cost',
    'summary': "ArchMeat MRP Cost",
    'website': 'http://altregy.com',
    'category': 'MRP',
    'version': '18.0.0.0.0',
    'depends': ['mrp_account_enterprise'],
    'data': [
         'views/mrp_production_view.xml',
         'views/res_company_view.xml',
         'reports/cost_structure_report.xml',
         'security/reviewer_security.xml',

    ],
    'license': "OPL-1",
    'installable': True,
    'application': False,
}