# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
import logging
from odoo.exceptions import ValidationError
from odoo.tools import float_round

_logger = logging.getLogger(__name__)


class MrpProduction(models.Model):
    _inherit = "mrp.production"

    cost_valid = fields.Boolean(string='Costos Validados', store=True, default=False, tracking=True)
    sales_price = fields.Float(string='Precio de Venta', copy=True, store=True)
    show_sales_price = fields.Boolean(string='Mostrar Precio de Venta', compute='_compute_show_sales_price')

    def _compute_show_sales_price(self):
        self.show_sales_price = self.env.company.sales_price_cost

    def button_mark_done(self):
        sales_price_sum = 0
        for po in self:
            if not po.cost_valid:
                raise ValidationError(_("No es posible terminar la orden sin validar los costos."))

        action = super(MrpProduction, self).button_mark_done()
        _logger.info('entrando a mark done')
        _logger.info(action)

        if self.env.company.sales_price_cost:
            for po in self:
                # Calcular el precio de venta total
                for line in po.move_finished_ids:
                    if line.product_id == po.product_id:
                        sales_price_sum += line.product_uom_qty * po.sales_price
                    else:
                        sales_price_sum += line.product_uom_qty * line.mrp_sales_price

                if sales_price_sum == 0:
                    raise ValidationError(_("No es posible realizar el cálculo de costos sin precios de venta."))

                # Obtener el costo total de los componentes
                total_cost = 0
                for line in po.move_raw_ids:
                    total_cost += line.product_id.standard_price * line.product_uom_qty

                # Recalcular cost_share para subproductos
                for line in po.move_finished_ids:
                    if line.product_id != po.product_id:
                        line.cost_share = line.product_uom_qty * line.mrp_sales_price / sales_price_sum * 100
                        cost_share = line.cost_share

                        # Ajustar asientos contables
                        journal = self.env["account.move"].with_context(check_move_validity=False).search([
                            ('stock_move_id', '=', line.id)
                        ])
                        for journal_line in journal.line_ids:
                            if journal_line.debit != 0:
                                journal_line.debit = cost_share / 100 * total_cost
                            else:
                                journal_line.credit = cost_share / 100 * total_cost

                        # Ajustar stock valuation layer
                        svl = self.env["stock.valuation.layer"].search([('stock_move_id', '=', line.id)])
                        for svl_item in svl:
                            svl_item.value = cost_share / 100 * total_cost
                            svl_item.remaining_value = cost_share / 100 * total_cost
                            svl_item.unit_cost = (cost_share / 100 * total_cost) / svl_item.quantity if svl_item.quantity else 0

                # Para el producto principal
                for line in po.move_finished_ids:
                    if line.product_id == po.product_id:
                        cost_share = float_round(
                            100 - sum(po.move_finished_ids.filtered(lambda l: l.product_id != po.product_id).mapped('cost_share')),
                            precision_rounding=0.0001
                        )

                        journal = self.env["account.move"].with_context(check_move_validity=False).search([
                            ('stock_move_id', '=', line.id)
                        ])
                        for journal_line in journal.line_ids:
                            if journal_line.debit != 0:
                                journal_line.debit = cost_share / 100 * total_cost
                            else:
                                journal_line.credit = cost_share / 100 * total_cost

                        svl = self.env["stock.valuation.layer"].search([('stock_move_id', '=', line.id)])
                        for svl_item in svl:
                            svl_item.value = cost_share / 100 * total_cost
                            svl_item.remaining_value = cost_share / 100 * total_cost
                            svl_item.unit_cost = (cost_share / 100 * total_cost) / svl_item.quantity if svl_item.quantity else 0

        return action


class StockMove(models.Model):
    _inherit = "stock.move"

    mrp_sales_price = fields.Float(string='Precio de Venta', copy=True, store=True)
    mrp_show_sales_price = fields.Boolean(string='Mostrar Precio de Venta', compute='_compute_mrp_show_sales_price')

    def _compute_mrp_show_sales_price(self):
        self.mrp_show_sales_price = self.env.company.sales_price_cost
