#. Go to Invoicing > Customers > Invoices and enter an invoice.
#. Click on "Reset to draft"
#. Click on "Cancel entry
#. Try to delete invoice
