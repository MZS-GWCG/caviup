# -*- coding: utf-8 -*-

from . import report_facturas_de_clientes_or_proveedores
from . import payment_report_from_xml