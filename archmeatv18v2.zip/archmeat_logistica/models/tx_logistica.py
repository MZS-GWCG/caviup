# -*- coding: utf-8 -*-
from datetime import datetime
import logging

from odoo import api, fields, models, _
import pytz

_logger = logging.getLogger(__name__)


class TxLogistica(models.Model):
    _name = "tx.logistica"
    _inherit = ['mail.thread', 'mail.activity.mixin', 'portal.mixin']
    _description = "Transaccion Logistica"
    _rec_name = 'name'
    _order = "name"

    name = fields.Char('Name', required=True, translate=True, tracking=True, default=lambda self: _('New'))
    company_id = fields.Many2one('res.company', default=lambda self: self.env.company, string='Company', index=True, store=True)
    transport_partner_id = fields.Many2one('res.partner', string='Línea de Transporte', store=True, domain="[('transport', '=', True)]")
    transport_partner_name = fields.Char(string='Nombre Transportista', compute='_compute_transport_partner_name', readonly=True)
    customer_delivery_plan = fields.Date('Entrega Cliente Plan', tracking=True)
    customer_delivery_real = fields.Date('Entrega Cliente Real', tracking=True)
    trailer_number = fields.Char('# Económico', tracking=True)
    temp_c = fields.Integer('Temp. °C', tracking=True)
    temp_f = fields.Integer('Temp. °F', tracking=True)
    delivery_appointment = fields.Boolean('Cita Entrega', tracking=True)
    delivery_appointment_id = fields.Char('Folio Cita', tracking=True)
    delivery_appointment_date = fields.Datetime('Fecha Cita', tracking=True)

    border_delivery_plan = fields.Date(string='Entrega en frontera plan', related='purchase_order_id.border_delivery_plan', readonly=True)
    border_delivery_real = fields.Date(string='Entrega en frontera real', related='purchase_order_id.border_delivery_real', readonly=True)
    product_names = fields.Char(string='Producto', compute='_compute_product_names', readonly=True)
    vendor_partner_id = fields.Many2one('res.partner', string='Proveedor', related='purchase_order_id.partner_id', readonly=True)
    vendor_partner_name = fields.Char(string='Nombre Proveedor', compute='_compute_vendor_partner_name', readonly=True)

    origin_plant_id = fields.Many2one('res.partner.origin.location', string='Planta Origen', related='purchase_order_id.origin_plant_id', readonly=True)
    purchase_order_id = fields.Many2one('purchase.order', string='Purchase Order', check_company=True, index=True)
    vendor_po = fields.Char(string='OC Proveedor', related='purchase_order_id.vendor_po', readonly=True)
    customs_agency_id = fields.Many2one('res.partner', string='Agencia Aduanal', related='purchase_order_id.customs_agency_id', readonly=True)
    customs_agency_name = fields.Char(string='Nombre Agencia Aduanal', compute='_compute_customs_agency_name', readonly=True)

    purchase_type = fields.Selection(string='Tipo de Compra', related='purchase_order_id.purchase_type', readonly=True)
    customer_partner = fields.Many2one('res.partner', string='Nombre Cliente', compute='_compute_customer_partner', readonly=True)
    customer_partner_name = fields.Char(string='Nombre Cliente', compute='_compute_customer_partner_name', readonly=True)
    delivery_address = fields.Many2one('res.partner', string='Dirección Entrega', compute='_compute_delivery_address', readonly=True)

    sale_order_input = fields.Many2one('sale.order', string='Pedido', domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]", store=True, check_company=True)
    sale_order = fields.Many2one('sale.order', string='Pedido', compute='_compute_sale_order', check_company=True)
    salesman = fields.Many2one('res.users', string='Vendedor', compute='_compute_salesman', readonly=True)

    pedimento = fields.Char('Pedimento', tracking=True)
    unspsc_code_id = fields.Many2one('product.unspsc.code', string='Código UNSPSC', tracking=True)
    tax_fraction = fields.Char('Fracción Arancelaria', tracking=True)
    qty = fields.Integer('Cantidad Kilos/Cajas', tracking=True)
    kilos = fields.Float('Kilos', tracking=True)
    hazardous_material = fields.Boolean('Material Peligroso', tracking=True)

    stage_id = fields.Many2one('tx.logistica.stage', string='Stage', index=True, tracking=True, compute='_compute_stage_id', store=True, copy=False, ondelete='restrict')

    # ✅ CAMBIO CRÍTICO: Se convierte en Selection
    stage_color = fields.Selection([
        ('success', 'Verde'),
        ('info', 'Azul'),
        ('danger', 'Rojo'),
        ('muted', 'Gris'),
        ('primary', 'Violeta'),
        ('warning', 'Amarillo')],
        string='Stage Color', compute='_compute_stage_color', readonly=True)

    days_due = fields.Integer(string='Days to Due', compute='_compute_days_to_due', readonly=True)
    elapsed_days = fields.Integer(string='Elapsed Days', compute='_compute_elapsed_days', readonly=True)
    due_state = fields.Selection([
        ('ontime', 'On Time'),
        ('closeto', 'Close to Due'),
        ('due', 'Due')], string='Due State', compute='_compute_due_state', readonly=True, default="ontime")

    @api.depends('customer_delivery_plan')
    def _compute_due_state(self):
        for line in self:
            line.due_state = "ontime"
            if 2 > line.days_due >= 0:
                line.due_state = "closeto"
            elif line.days_due < 0:
                line.due_state = "due"

    @api.depends('stage_id.color')
    def _compute_stage_color(self):
        for shipment in self:
            shipment.stage_color = shipment.stage_id.color if shipment.stage_id else False

    @api.depends('purchase_order_id')
    def _compute_product_names(self):
        for tx in self:
            names = [line.name for line in tx.purchase_order_id.order_line] if tx.purchase_order_id else []
            tx.product_names = "; ".join(names)

    @api.depends('vendor_partner_id')
    def _compute_vendor_partner_name(self):
        for tx in self:
            tx.vendor_partner_name = tx.vendor_partner_id.name if tx.vendor_partner_id else ""

    @api.depends('transport_partner_id')
    def _compute_transport_partner_name(self):
        for tx in self:
            tx.transport_partner_name = tx.transport_partner_id.name if tx.transport_partner_id else ""

    @api.depends('customs_agency_id')
    def _compute_customs_agency_name(self):
        for tx in self:
            tx.customs_agency_name = tx.customs_agency_id.name if tx.customs_agency_id else ""

    @api.depends('customer_partner')
    def _compute_customer_partner_name(self):
        for tx in self:
            tx.customer_partner_name = tx.customer_partner.name if tx.customer_partner else ""

    @api.depends('sale_order')
    def _compute_customer_partner(self):
        for tx in self:
            tx.customer_partner = tx.sale_order.partner_id if tx.sale_order else False

    @api.depends('sale_order')
    def _compute_delivery_address(self):
        for tx in self:
            tx.delivery_address = tx.sale_order.partner_shipping_id if tx.sale_order else False

    @api.depends('purchase_order_id', 'sale_order_input')
    def _compute_sale_order(self):
        for tx in self:
            if tx.purchase_order_id and tx.purchase_order_id._get_sale_orders():
                tx.sale_order = tx.purchase_order_id._get_sale_orders()[0]
            else:
                tx.sale_order = tx.sale_order_input

    @api.depends('sale_order')
    def _compute_salesman(self):
        for tx in self:
            tx.salesman = tx.sale_order.user_id if tx.sale_order else False

    def _compute_stage_id(self):
        for shipment in self:
            if not shipment.stage_id:
                shipment.stage_id = shipment._stage_find().id

    def _stage_find(self, domain=None, order='sequence', limit=1):
        search_domain = domain or []
        return self.env['tx.logistica.stage'].search(search_domain, order=order, limit=limit)

    @api.model
    def create(self, vals):
        company_id = vals.get('company_id')
        self_comp = self.with_company(company_id)
        if vals.get('name', 'New') == 'New':
            vals['name'] = self_comp.env['ir.sequence'].next_by_code('tx.logistica') or '/'
        if vals.get('stage_id', 'New') == 'New':
            vals['stage_id'] = self._stage_find().id
        return super(TxLogistica, self_comp).create(vals)

    @api.depends('customer_delivery_plan')
    def _compute_days_to_due(self):
        for tx in self:
            today = tx._get_localized_date().date()
            tx.days_due = (tx.customer_delivery_plan - today).days if tx.customer_delivery_plan else 0

    @api.depends('customer_delivery_real', 'purchase_order_id.date_approve')
    def _compute_elapsed_days(self):
        for tx in self:
            now = tx._get_localized_date().date()
            start = tx.purchase_order_id.date_approve
            end = tx.customer_delivery_real or now
            tx.elapsed_days = (end - start).days if start else 0

    def _get_localized_date(self):
        now = datetime.now()
        tz_name = self.env.context.get('tz') or self.env.user.tz
        utc_now = pytz.utc.localize(now)
        if tz_name:
            try:
                return utc_now.astimezone(pytz.timezone(tz_name))
            except Exception:
                _logger.warning("Timezone conversion failed; using UTC.", exc_info=True)
