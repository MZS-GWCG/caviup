# -*- coding: utf-8 -*-

from odoo import models, fields, api, _

DEFAULT_CFDI_DATE_FORMAT = '%Y-%m-%dT%H:%M:%S'

class AccountInvoice(models.Model):
    _inherit = 'account.move'

    l10n_mx_edi_cfdi_uuid = fields.Char(string='Folio Fiscal Sync', copy=False, readonly=True,
        help='Folio in electronic invoice, is returned by SAT when send to stamp.',) #compute='_compute_cfdi_values', store=True
    attachment_id = fields.Many2one("ir.attachment", 'Attachment Sync')
    folio_fiscal = fields.Char(string=_('Folio Fiscal'), readonly=True)
    forma_pago_id = fields.Many2one('catalogo.forma.pago', string='Forma de pago')
    uso_cfdi_id = fields.Many2one('catalogo.uso.cfdi', string='Uso CFDI (cliente)')
    methodo_pago = fields.Selection(
        selection=[('PUE', _('Pago en una sola exhibición')),
                   ('PPD', _('Pago en parcialidades o diferido')), ],
        string=_('Método de pago'),
    )
    number_folio = fields.Char(string=_('Folio'))
    tipo_comprobante = fields.Selection(
        selection=[('I', 'Ingreso'),
                   ('E', 'Egreso'),
                   ('T', 'Traslado'),
                   ],
        string=_('Tipo de comprobante'),
    )
    estado_factura = fields.Selection(
        selection=[('factura_no_generada', 'Factura no generada'), ('factura_correcta', 'Factura correcta'),
                   ('solicitud_cancelar', 'Cancelación en proceso'), ('factura_cancelada', 'Factura cancelada'),
                   ('solicitud_rechazada', 'Cancelación rechazada'), ],
        string=_('Estado de factura'),
        default='factura_no_generada',
        readonly=True
    )
    tipocambio = fields.Char(string=_('TipoCambio'))
    moneda = fields.Char(string=_('Moneda'))
    numero_cetificado = fields.Char(string=_('Numero de cetificado'))
    fecha_certificacion = fields.Char(string=_('Fecha y Hora Certificación'))
    fecha_factura = fields.Datetime(string=_('Fecha Factura'))
    selo_digital_cdfi = fields.Char(string=_('Selo Digital del CDFI'))
    selo_sat = fields.Char(string=_('Selo del SAT'))
    total_factura = fields.Float("Total factura")
    cetificaso_sat = fields.Char(string=_('Cetificao SAT'))
    cadena_origenal = fields.Char(string=_('Cadena Origenal del Complemento digital de SAT'))
    factura_cfdi = fields.Boolean('Factura CFDI')
    tipo_relacion = fields.Selection(
        selection=[('01', 'Nota de crédito de los documentos relacionados'),
                   ('02', 'Nota de débito de los documentos relacionados'),
                   ('03', 'Devolución de mercancía sobre facturas o traslados previos'),
                   ('04', 'Sustitución de los CFDI previos'),
                   ('05', 'Traslados de mercancías facturados previamente'),
                   ('06', 'Factura generada por los traslados previos'),
                   ('07', 'CFDI por aplicación de anticipo'), ],
        string=_('Tipo relación'),
    )
    uuid_relacionado = fields.Char(string=_('CFDI Relacionado'))