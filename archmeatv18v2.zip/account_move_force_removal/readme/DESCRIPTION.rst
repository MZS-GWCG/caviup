This module allows you to delete account moves, which is prevented in Odoo by default.
You must care yourself about the numbering sequence doing this.
