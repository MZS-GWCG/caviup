# -*- coding: utf-8 -*-

from odoo import api, fields, models
from odoo.exceptions import AccessError, UserError, ValidationError


class PurchaseOrder(models.Model):
    _inherit = "purchase.order"

    tx_logistica_ids = fields.One2many('tx.logistica', 'purchase_order_id', string='Vendor Shipment', copy=False)
    tx_logistica_count = fields.Integer(compute="_compute_vs", string='Vendor Shipment Count', copy=False, default=0, store=True)
    border_delivery_plan = fields.Date('Entrega en frontera plan')
    border_delivery_real = fields.Date('Entrega en frontera real')
    origin_plant_id = fields.Many2one('res.partner.origin.location', string='Planta Origen', store=True, domain="[('partner_id', '=?', partner_id)]")
    vendor_po = fields.Char('OC Proveedor')
    customs_agency_id = fields.Many2one('res.partner', string='Agencia Aduanal', store=True, domain="[('customs_agency', '=', True)]")
    purchase_type = fields.Selection([
        ('import', 'Importación o Venta Directa'),
        ('subcontracted', 'Maquila'),
        ('unsold', 'Unsold')], string='Tipo de Compra', default="import")

    @api.depends('tx_logistica_ids')
    def _compute_vs(self):
        for order in self:
            order.tx_logistica_count = self.env['tx.logistica'].search_count([('purchase_order_id', '=', order.id)])

    def action_create_tx_logistica(self):
        vs_vals_list = []

        for order in self:
            order = order.with_company(order.company_id)
            vs_vals_list = order._prepare_vs()

        if not vs_vals_list:
            raise UserError('No fue posible generar la transacción logística')

        vs_move = self.env['tx.logistica']
        moves = vs_move.with_company(vs_vals_list['company_id']).create(vs_vals_list)

        return self.action_view_tx_logistica(moves)

    def _prepare_vs(self):
        self.ensure_one()
        vs_vals = {
            'purchase_order_id': self.id,
            'company_id': self.company_id.id,
        }
        return vs_vals

    def action_view_tx_logistica(self, vs_moves=False):
        if not vs_moves:
            for order in self:
                vs_moves = self.env['tx.logistica'].search([('purchase_order_id', '=', order.id)])

        result = self.env['ir.actions.act_window']._for_xml_id('archmeat_logistica.action_archmeat_tx_logistica')
        # choose the view_mode accordingly
        if len(vs_moves) > 1:
            result['domain'] = [('id', 'in', vs_moves.ids)]
        elif len(vs_moves) == 1:
            res = self.env.ref('archmeat_logistica.archmeat_tx_logistica_form_view', False)
            form_view = [(res and res.id or False, 'form')]
            if 'views' in result:
                result['views'] = form_view + [(state, view) for state, view in result['views'] if view != 'form']
            else:
                result['views'] = form_view
            result['res_id'] = vs_moves.id
        else:
            result = {'type': 'ir.actions.act_window_close'}

        return result