{
    'name': 'ArchMeat Logistica',
    'summary': "ArchMeat Logistica",
    'website': 'http://altregy.com',
    'category': 'Purchase',
    'version': '18.0.0.0.0',
    'depends': ['sale_purchase','product_unspsc','base_address_extended','l10n_mx_edi'],
    'data': [
        'security/ir.model.access.csv',
        'views/res_partner_views.xml',
        'views/purchase_order_views.xml',
        'views/tx_logistica_views.xml',
        'views/tx_logistica_stage_views.xml',
        'report/tx_logistica_report.xml',

    ],
    'license': "OPL-1",
    'installable': True,
    'application': False,
}