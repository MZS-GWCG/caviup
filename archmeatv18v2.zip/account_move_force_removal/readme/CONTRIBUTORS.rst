* `Tecnativa <https://www.tecnativa.com>`_:

  * Víctor Martínez
  * Pedro M. Baeza
* Alex Comba <alex.comba@agilebg.com>

* `Sygel <https://www.sygel.es>`__:

  * Ángel García de la Chica Herrera
