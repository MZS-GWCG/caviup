from odoo import api, fields, models
import logging

_logger = logging.getLogger(__name__)


class ResCompany(models.Model):
    _inherit = "res.company"

    sales_price_cost = fields.Boolean(string='Costeo basado en Precio de Venta', copy=True, store=True)
