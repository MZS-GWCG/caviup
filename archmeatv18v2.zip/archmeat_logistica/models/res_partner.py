# -*- coding: utf-8 -*-

from odoo import api, fields, models


class ResPartner(models.Model):
    _inherit = "res.partner"

    customs_agency = fields.Boolean(string='Agencia Aduanal', copy=True)
    transport = fields.Boolean(string='Transportista', copy=True)
    origin_location_ids = fields.One2many('res.partner.origin.location', 'partner_id', string='Planta Origen', copy=False)
    print_contact = fields.Char(string='Contacto Hoja Instrucciones')
    print_address = fields.Char(string='Dirección', compute='_compute_print_address', readonly=True)

    def _compute_print_address(self):
        address = "{street} {street_number} {street_number2}, {l10n_mx_edi_colony}".format(
            street=self.street if self.street else "",
            street_number=self.street_number if self.street_number else "",
            street_number2=self.street_number2 if self.street_number2 else "",
            l10n_mx_edi_colony=self.l10n_mx_edi_colony if self.l10n_mx_edi_colony else "",
            )
        self.print_address = address


class ResPartnerOriginLocations(models.Model):
    _name = "res.partner.origin.location"
    _description = "Proveedor Planta Origen"
    _rec_name = 'name'

    partner_id = fields.Many2one('res.partner', string='Contacto', copy=True)
    name = fields.Char('Planta Origen', required=True, translate=True)
    state_id = fields.Many2one("res.country.state", string='Estado', ondelete='restrict', domain="[('country_id', '=?', country_id)]")
    country_id = fields.Many2one('res.country', string='País', ondelete='restrict')