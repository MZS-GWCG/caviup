# -*- coding: utf-8 -*-

from . import tx_logistica_stage
from . import tx_logistica
from . import purchase
from . import res_partner

